/* 
 * File:   Comunicaci�n USART.h
 * Author: Lisandro Toru�o
 * Comments: Sirve para comunicaci�n PIC a PIC
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef UART_H
#define	UART_H

#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdint.h>

void USART_CONFIG(void);
void UART_write(unsigned char* word);

#endif	/* UART_H */