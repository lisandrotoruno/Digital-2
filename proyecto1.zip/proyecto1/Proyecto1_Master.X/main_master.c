/*
 * File:   main_master.c
 * Author: lisan
 *
 * Created on 8 de septiembre de 2022, 08:49 AM
 */
// CONFIG1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

#include <xc.h>
#include <stdlib.h> //libreria de string
#include <stdio.h>
#include <stdint.h>
#include "UART.h"
#include "SPI.h"
#include "LCD_8b.h"

/*-------- CONSTANTES --------*/
#define XTAL_FREQ 4000000
/*-------- VARIABLES --------*/
uint8_t presion,luz,ang;
uint8_t presion_cen, presion_dec, presion_uni;
uint8_t ang_cen, ang_dec, ang_uni;
uint8_t luz_mil, luz_cen, luz_dec, luz_uni;
uint8_t door;

/*-------- FUNCIONES ------*/
void setup(void);
uint8_t ASCII_Decimal(uint8_t variable, uint8_t seleccionar);

/*------- INTERRUPCIONES -------*/
void __interrupt() isr(void)
{    
    if (RCIF)
    {
        TXREG = 97;
        while(!TXSTAbits.TRMT);
        presion_cen = RCREG;
        TXREG = 98;
        while(!TXSTAbits.TRMT);
        presion_dec = RCREG;
        TXREG = 99;
        while(!TXSTAbits.TRMT);
        presion_uni = RCREG;
        
        TXREG = 100;
        while(!TXSTAbits.TRMT);
        luz_mil = RCREG;
        TXREG = 101;
        while(!TXSTAbits.TRMT);
        luz_cen = RCREG;
        TXREG = 102;
        while(!TXSTAbits.TRMT);
        luz_dec = RCREG;
        TXREG = 103;
        while(!TXSTAbits.TRMT);
        luz_uni = RCREG;
        
        TXREG = 104;
        while(!TXSTAbits.TRMT);
        ang_cen = RCREG;
        TXREG = 105;
        while(!TXSTAbits.TRMT);
        ang_dec = RCREG;
        TXREG = 106;
        while(!TXSTAbits.TRMT);
        ang_uni = RCREG;
        
        TXREG = 107;
        while(!TXSTAbits.TRMT);
        door = RCREG;
        
        if(RCREG == 0x21){PORTB = 1;}
    }
}
void main(void) 
{
    setup();
    while(1)
    {
        /*----------- QUE APAREZCA LA INFO EN LA LCD-----------*/
        
        Lcd_Set_Cursor(2,1);
        Lcd_Write_String(presion);
        __delay_ms(50);
        
        Lcd_Set_Cursor(2,4);
        Lcd_Write_String(luz);
        __delay_ms(50);
        
        Lcd_Set_Cursor(2,6);
        Lcd_Write_String(ang);
        __delay_ms(50);
        
        Lcd_Set_Cursor(2,8);
        Lcd_Write_String(door);
        __delay_ms(50);
        
        /*----------- CONVERSI�N DE ASCII A DECIMAL -----------*/
        uint8_t temp_door;
        switch(door)
        {
            case 0x30:
                temp_door = 0;
                break;
            case 0x31:
                temp_door = 1;
                break;
        }
        luz = ASCII_Decimal(luz_uni,0)+ASCII_Decimal(luz_dec,1)+ASCII_Decimal(luz_dec,2)+ASCII_Decimal(luz_mil,3);
        ang = ASCII_Decimal(ang_uni,0)+ASCII_Decimal(ang_dec,1)+ASCII_Decimal(ang_cen,2);
        presion = ASCII_Decimal(presion_uni,0)+ASCII_Decimal(presion_dec,1)+ASCII_Decimal(presion_cen,2);
        
        /*----------- COMUNICACI�N SPI-----------*/
        spiWrite(temp_door);
        spiWrite(luz);
        spiWrite(ang);
        spiWrite(presion);
    }
    return;
}

void setup(void)
{
    ANSEL = 0;
    ANSELH = 0;
    
    PORTA = 0;
    PORTB = 0;
    PORTC = 0;
    PORTD = 0;
    PORTE = 0;
    TRISA = 0;
    TRISB = 0;
    TRISC = 0;
    TRISD = 0;
    
    OSCCONbits.IRCF = 0b110;    // 4MHz
    SCS = 1;
    
    RCSTAbits.SPEN = 1;
    TXSTAbits.TX9 = 0;
    RCSTAbits.RX9 = 0;
    SPBRG = 12;
    TXSTAbits.SYNC = 0;
    TXSTAbits.BRGH = 0;
    BAUDCTLbits.BRG16 = 0;
    TXEN = 1;
    RCEN = 1;
    
    spiInit(SPI_MASTER_OSC_DIV4, SPI_DATA_SAMPLE_MIDDLE, 
            SPI_CLOCK_IDLE_LOW,SPI_IDLE_2_ACTIVE);
    
    Lcd_Init();
    Lcd_Clear();
    Lcd_Set_Cursor(1,1);
    Lcd_Write_String("pa lx ang door"); 
}

uint8_t ASCII_Decimal(uint8_t variable, uint8_t seleccionar)
{
    uint8_t valor;
    
    valor = variable;
    valor = valor - 48; //Quitar los 48 que se le suman para conversi�n de ascii
    switch(seleccionar)
    {
        case 0: //Unidades
            return valor;
            break;
        case 1: //Decenas
            valor = valor*10;
            return valor;
            break;
        case 2: //Centenas
            valor = valor*100;
            return valor;
            break;
        case 3: //Millares   
            valor = valor *1000;
            return valor;
            break;
    }
}
