#include "LCD_8b.h"

void Lcd_Port(char a)
{   // SI AL MULTIPLICAR DA 1 SE PRENDE D
    if (a & 1)
        D0 = 1;
    else
        D0 = 0;

    if (a & 2)
        D1 = 1;
    else
        D1 = 0;

    if (a & 4)
        D2 = 1;
    else
        D2 = 0;

    if (a & 8)
        D3 = 1;
    else
        D3 = 0;
    
    if (a & 1)
        D4 = 1;
    else
        D4 = 0;

    if (a & 2)
        D5 = 1;
    else
        D5 = 0;

    if (a & 4)
        D6 = 1;
    else
        D6 = 0;

    if (a & 8)
        D7 = 1;
    else
        D7 = 0;
}

void Lcd_Cmd(char a)
{
    RS = 0; //D0 a D7 considerado como cmd
    PORTD = a;
    //Lcd_Port(a);
    EN = 1;
    __delay_ms(4);
    EN = 0; //Los datos\cmd se esran transfirieron al LCD
}

void Lcd_Clear(void) 
{
    Lcd_Cmd(0);
    Lcd_Cmd(1); //Borra el visualizador
}

void Lcd_Set_Cursor(char a, char b)
{
    //char temp, z, y;
    if (a == 1) //Si es la primera columna
    {
        Lcd_Cmd((b & 0X0F) | 0x80);
        //temp = 0x80 + b - 1; // Temporalmente guarda el valor
        //z = temp >> 4;       // Se corre 4 bits hacia la derecha
        //y = temp & 0x0F;     // Nos quedamos con el nibble menos significativo   
        //Lcd_Cmd(z);          // Mandamos el comando de z
        //Lcd_Cmd(y);          // Mandamos el comando de y
    } 
    else if (a == 2)         // Si se elige la segunda columna
    {                        // Guardamos el valor temporal de lo que se colocar� abajo y que transfiera los datos.
        Lcd_Cmd((b & 0X0F) | 0xC0);
        //temp = 0xC0 + b - 1;
        //z = temp >> 4;
        //y = temp & 0x0F;
        //Lcd_Cmd(z);
        //Lcd_Cmd(y);
    }
}

void Lcd_Init(void) 
{
    PORTD = (0x00);
    __delay_ms(20);
    Lcd_Cmd(0x30);      //0011 0000
    __delay_ms(5);
    Lcd_Cmd(0x30);      //0011 0000
    __delay_ms(11);
    Lcd_Cmd(0x30);      //0011 0000
    /////////////////////////////////////////////////////
    Lcd_Cmd(0x38);      //0011 1000
    Lcd_Cmd(0x10);      //0000 1000
    Lcd_Cmd(0x01);      //0000 0001
    Lcd_Cmd(0x06);      //0000 0110
    Lcd_Cmd(0x10);
    Lcd_Cmd(0x0C);
    __delay_ms(100);
}

void Lcd_Write_Char(char a) 
{
    //char temp, y;
    //temp = a & 0x0F;    //Se guarda el nibble menos significativo
    //y = a & 0xF0;       //Se guarda el nibble m�s significativo
    RS = 1;             //Se consideran datos
    PORTD = a;
    EN = 1;             //Transmita los datos a LCD
    __delay_us(40);
    //EN = 0;             
    //Lcd_Port(temp);     //Los datos del temp se transmiten a la LCD
    //EN = 1;
    //delay_us(40);
    EN = 0;
}

void Lcd_Write_String(char *a) 
{
    int i;
    for (i = 0; a[i] != '\0'; i++)  //Si no es la final de la cadena no sale del for, entonces aumenta en uno
        Lcd_Write_Char(a[i]);       //Transfiere los datos al LCD
}

void Lcd_Shift_Right(void) 
{
    Lcd_Cmd(0x01);              // Se habilita el desplazador
    Lcd_Cmd(0x0C);              // Desplaza el visualizador hacia la derecha
}

void Lcd_Shift_Left(void) 
{
    Lcd_Cmd(0x01);              // Se habilita el desplazador
    Lcd_Cmd(0x08);              // Desplaza el visualizador hacia la izquierda
}

