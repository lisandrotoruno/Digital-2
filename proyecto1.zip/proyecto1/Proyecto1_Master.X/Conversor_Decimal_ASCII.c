/* 
 * File:   Conversor_Decimal_ASCII.c
 * Author: 50247
 *
 * Created on 23 de septiembre de 2022, 09:11 AM
 */

#include <stdio.h>
#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) {

    return (EXIT_SUCCESS);
}

