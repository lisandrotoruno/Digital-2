#include <xc.h>
#include <stdint.h>
#include "UART.h"

void USART_Config(void){
    RCSTAbits.SPEN = 1;
    TXSTAbits.TX9 = 0;
    RCSTAbits.RX9 = 0;
    SPBRG = 12;
    TXSTAbits.SYNC = 0;
    TXSTAbits.BRGH = 0;
    BAUDCTLbits.BRG16 = 0;
    TXEN = 1;
    RCEN = 1;
}

void UART_write(unsigned char* word ){   //Funci�n que transmite datos
    while (*word != 0){                 //Verifica que el puntero aumente
        TXREG = (*word);                //Env�a el caracter que toca de la cadena
        while(!TXSTAbits.TRMT);         //Espera a que se haya enviado el dato
        word++;                         //Aumenta el apuntador para ir al
        //siguiente caracter
    }                                   
    return;
}
