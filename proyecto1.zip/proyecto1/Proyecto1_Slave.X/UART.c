#include <xc.h>
#include <stdint.h>
#include "UART.h"

void USART_Config(int frec,int tr,int rc){
    RCSTAbits.SPEN = 1;
    TXSTAbits.TX9 = 0;
    RCSTAbits.RX9 = 0;
    switch(frec){
        default:
            SPBRG = 12;
            TXSTAbits.SYNC = 0;
            TXSTAbits.BRGH = 0;
            BAUDCTLbits.BRG16 = 0;
            break;     
    }
    switch (tr){
        case 1:
            TXEN = 1;
            break;
        default:
            TXEN = 0;
            break;
    }
    switch (rc){
        case 1:
            RCEN = 1;
            break;
        default:
            RCEN = 0;
            break;
    }
}

void UART_write(unsigned char* word){   //Funci�n que transmite datos
    while (*word != 0){                 //Verifica que el puntero aumente
        TXREG = (*word);                //Env�a el caracter que toca de la cadena
        while(!TXSTAbits.TRMT);         //Espera a que se haya enviado el dato
        word++;                         //Aumenta el apuntador para ir al
    }                                   //siguente caracter
    return;
}

