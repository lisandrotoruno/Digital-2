 /*
 * File            : I2C.c
 * Author          : Ligo George
 * Company         : electroSome
 * Project         : I2C Library for MPLAB XC8
 * Microcontroller : PIC 16F877A
 * Created on April 15, 2017, 5:59 PM
 * Link: https://electrosome.com/i2c-pic-microcontroller-mplab-xc8/
 * Modificada por: Pablo Mazariegos con la ayuda del auxiliar Gustavo Ordo�ez 
 * Basado en Link: http://microcontroladores-mrelberni.com/i2c-pic-comunicacion-serial/
 */
#include "I2C.h"

void I2C_Master_Init(const unsigned long c)
{
    SSPCON = 0b00101000; // Enables the serial port and configures the SDA and SCL pins as the source of the serial port pins y 
                         // I2C Master mode, clock = FOSC / (4 * (SSPADD+1))
    SSPCON2 = 0;         // Start condition Idle y Repeated condition Idle, stop Condition Idle , Receive Idle, ACK de Idle, ACK, ACK is receive from slave 
                         // General  call address disable.
    SSPADD = (_XTAL_FREQ/(4*c))-1;  //Guardamos la direcci�n del maestro al SSPADD
    SSPSTAT = 0;                    // El dato se transmite por rising edge del SCK, Slew rate control enabled for high speed mode (400 kHz). todav�a no comienza ni termina , 
                                    // est� en Write, Transmit is not in progress, y  Data transmit complete (does not include the ACK and Stop bits), SSPBUF is empty
    TRISCbits.TRISC3 = 1;           //SCK entrada
    TRISCbits.TRISC4 = 1;           //SDI entrada
}

void I2C_Master_Wait()
{
    while ((SSPSTAT & 0x04) || (SSPCON2 & 0x1F));   //Esperar que termine de transmitir o que se apage el ACK y SDA con SCL.
}

void I2C_Master_Start()
{
    I2C_Master_Wait();      //Esperamos que todo este sin que se transmita o prenda el ACK
    SSPCON2bits.SEN = 1;    // Initiate Start condition on SDA and SCL pins. Automatically cleared by hardware.
}

void I2C_Master_RepeatedStart()
{
    I2C_Master_Wait();      //Esperamos que todo este sin que se transmita o prenda el ACK
    SSPCON2bits.RSEN = 1;   //  Initiate Repeated Start condition on SDA and SCL pins. Automatically cleared by hardware.
}

void I2C_Master_Stop()
{
    I2C_Master_Wait();      //Esperamos que todo este sin que se transmita o prenda el ACK
    SSPCON2bits.PEN = 1;    // Initiate Stop condition on SDA and SCL pins. Automatically cleared by hardware.
}

void I2C_Master_Write(unsigned d)
{
    I2C_Master_Wait();     //Esperamos que todo este sin que se transmita o prenda el ACK
    SSPBUF = d;            //Cargamos el valor a enviar en el buffer 
}

unsigned short I2C_Master_Read(unsigned short a)
{
    unsigned short temp;    // Se asigna una variable de dato temporal
    I2C_Master_Wait();      // Esperamos que todo este sin que se transmita o prenda el ACK
    SSPCON2bits.RCEN = 1;   // Enables Receive mode for I2C
    I2C_Master_Wait();      // Esperamos que todo este sin que se transmita o prenda el ACK
    temp = SSPBUF;          // El valor temporal guarda el dato del buffer 
    I2C_Master_Wait();      // Esperamos que todo este sin que se transmita o prenda el ACK
    if(a == 1){             // si es 1, entonces:
        SSPCON2bits.ACKDT = 0;  //Acknowledge
    }else{
        SSPCON2bits.ACKDT = 1;  //Not Acknowledge
    }
    SSPCON2bits.ACKEN = 1;      // Initiate Acknowledge sequence on SDA and SCL pins, and transmit ACKDT data bit. Automatically cleared by hardware.
    return temp;                // Regresamos con el valor del buffer que se guardo en el temporal.
}

void I2C_Slave_Init(uint8_t address)
{ 
    SSPADD = address;           // La direcci�n del esclavo se guarda en SSP ADDRESS
    SSPCON = 0x36;              // I2C Slave mode, 7-bit address, Enable clock y Enable y config SDA y SCL. 
    SSPSTAT = 0x80;             // Slew rate control disabled for standard speed mode (100 kHz and 1 MHz)
    SSPCON2 = 0x01;             // Clock stretching is enabled for both slave transmit and slave receive (stretch enabled)
    TRISC3 = 1;                 // SCL es entrada.
    TRISC4 = 1;                 // SDA es entrada.
    SSPIF = 0;                  // Apagamos bandera
    SSPIE = 1;                  // Habilitamos SSP
    PEIE = 1;                   // Habilitamos la int. perif�rica
    GIE = 1;                    // Habilitamos la int. Generales 
}
