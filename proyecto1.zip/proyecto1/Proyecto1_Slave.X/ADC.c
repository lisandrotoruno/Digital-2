#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "ADC.h"


void adc_init(uint8_t adc_cs, uint8_t vref_plus, uint8_t vref_minus)
{
    //Config de ADC
    ADCON0bits.CHS = 0;
    ADCON1bits.ADFM = 0;        // Lectura hacia la izquierda.
    ADCON0bits.ADON = 1;
    __delay_ms(40);             // Sample time
    //HABILITAMOS LAS INT, Y APAGAMOS BANDERA
    PIR1bits.ADIF = 0;          // Limpiamos bandera de ADC
    PIE1bits.ADIE = 1;          // Habilitamos interrupcion de ADC
    
    //ADCS:
    switch(adc_cs)
    {
        case 0:
            ADCON0bits.ADCS = 3;    //F_RC
            break;
        case 1:
            ADCON0bits.ADCS = 0;    //Fosc/2
            break;
        case 2:
            ADCON0bits.ADCS = 1;    //Fosc/8
            break;
        case 3:
            ADCON0bits.ADCS = 2;    //Fosc/32
            break;
        default:
            ADCON0bits.ADCS = 2;    //Fosc/32
            break;
    };
    
    //Ref + y - de voltaje
    switch(vref_plus){
        case 0:
            ADCON1bits.VCFG0 = 0;
            break;
        case 1:
            ADCON1bits.VCFG0 = 1;
            break;
        default:
            ADCON1bits.VCFG0 = 0;
            break;
    };
    switch(vref_minus){
        case 0:
            ADCON1bits.VCFG1 = 0;
            break;
        case 1:
            ADCON1bits.VCFG1 = 1;
            break;
        default:
            ADCON1bits.VCFG1 = 0;
            break;
    };    
    __delay_ms(40);                 //Sample time
    
}

void adc_start()
{
    if (ADCON0bits.GO == 0){
        if(ADCON0bits.CHS == 0){
            //ADCON0bits.CHS = 1;
        }
        //else{
        //    ADCON0bits.CHS = 0;
        //}
        __delay_us(50);
        ADCON0bits.GO = 1;
    }
    return;
}


uint16_t adc_read(void)
{
    while(ADCON0bits.GO){}
    if (PIR1bits.ADIF){
        if(ADCON0bits.CHS == 0)
        {
            (uint8_t)((ADRESH << 8) | ADRESL);
        }
        else
        {
            (uint8_t)((ADRESH << 8) | ADRESL);
        }
        PIR1bits.ADIF = 0;
    }
}
uint8_t adc_read_pot1(void)
{
    if(ADIF)
    {
    if(ADCON0bits.CHS == 0)
        {
            ADRESH;
        }
    ADIF = 0;
    }
    return ADRESH;
}
uint8_t adc_read_pot2(void)
{
    if(ADIF)
    {
    if(ADCON0bits.CHS == 1)
        {
            ADRESH;
        }
    ADIF = 0;
    }
}

