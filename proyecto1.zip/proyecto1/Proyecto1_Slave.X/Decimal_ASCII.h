/* 
 * File:   Decimal_ASCII
 * Author: Lisandro Toru�o
 * Comments:
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef Decimal_ASCII_H
#define	Decimal_ASCII_H

#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

uint8_t uniunidades(uint8_t variable);
uint8_t decenasdecenas(uint8_t variable);
uint8_t centenascentenas(uint8_t variable);
uint8_t unidades(uint8_t variable);
uint8_t decenas(uint8_t variable);
uint8_t centenas(uint8_t variable);
uint8_t milares(uint8_t variable);
uint8_t decenas_unidades(uint8_t variable);
uint8_t decenas_decenas(uint8_t variable);
uint8_t unidades_decenas(uint8_t variable);

#endif	/* Decimal_ASCII_H */

