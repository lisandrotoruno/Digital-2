/* 
 * File: PWM.h  
 * Author: Lisandro Toru�o
 * Comments: Configura el PWM
 * Revision history: Ver si funciona correctamente
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef PWM_H
#define	PWM_H

#include <xc.h> // include processor files - each processor file is guarded.  
void PWM_CONFIG();

#endif	/* PWM_H */