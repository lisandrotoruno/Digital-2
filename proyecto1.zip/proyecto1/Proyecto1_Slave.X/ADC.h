/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef ADC_H
#define	ADC_H

#ifndef	_XTAL_FREQ
#define _XTAL_FREQ 4000000
#endif 

#include <xc.h> 
#include <stdio.h>
#include <stdlib.h>

void adc_init(uint8_t adc_cs, uint8_t vref_plus, uint8_t vref_minus);
void adc_start();
uint16_t adc_read(void);
uint8_t adc_read_pot1(void);
uint8_t adc_read_pot2(void);

#endif	/* ADC_H */