/*
 * File:   main_slave.c
 * Author: lisan
 *
 * Created on 8 de septiembre de 2022, 08:58 AM
 */
// CONFIG1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

#include <xc.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "ADC.h"
#include "BMP280.h"
#include "Decimal_ASCII.h"
#include "I2C.h"
#include "PWM.h"
#include "TSL2561.h"
#include "UART.h"

/*-------------- CONSTANTES ------------------*/
#define I2C_SPEED 100000        //Velocidad de comuniccaci�n I2C
#define ADDRESS 0x80            // Direcci�n del I2C Master
#define XTAL_FREQ 4000000       //frecuencia
/*-------------- VARIABLES -----------------*/
char motor, val, presion, ang, door;
uint8_t lux1, lux2, lux3, lux4;             //lux1 ya est� en milares
uint8_t presion_cen, presion_dec, presion_uni;
uint8_t ang_cen, ang_dec, ang_uni;
uint8_t lux2_mil, lux2_cen, lux2_dec, lux2_uni;
uint8_t lux3_cen, lux3_dec, lux3_uni;
uint8_t lux4_dec, lux4_uni;
uint8_t lux_mil, lux_cen, lux_dec, lux_uni;
/*-------------------- PROTOTIPO DE FUNCI�N ------------------------*/
unsigned short map(uint8_t x, uint8_t x0, uint8_t x1, 
            unsigned short y0, unsigned short y1);      //Mapeo

void setup(void);               //Configuracion inicial
void Decimal(uint8_t variable); //Conversor a ascii

/*------------------------------ INTERRUPCI�N -------------------------------*/
void __interrupt()isr(void)
{
    /*----------- INTERRUPCI�N ADC -----------*/
    if (ADIF)                       //Verifica si hay interrupci�n del m�dulo
    {                               //y verifica cual es el canal a convertir, el CH0 lo
        if (ADCON0bits.CHS == 0){   //muestrea el PWM con una transformaci�n para que tome 
            CCPR1L = (ADRESH>>1)+125;//los bits +sig 
            ang = map(ADRESH, 0, 255, 0, 100);
        }
        PIR1bits.ADIF = 0;
    }
    
    /*----------- INTERRUPCI�N DEL USART -----------*/
    if (RCIF)
    {
        val = RCREG;
        switch(val)
        {
            case 97:        //Si se recibe un "a" manda la informaci�n de las centenas presi�n:
                TXREG = (presion_cen);
                while(!TXSTAbits.TRMT);
                break;
                
            case 98:        //Si se recibe un "b" manda la informaci�n de las decenas presi�n:
                TXREG = (presion_dec);
                while(!TXSTAbits.TRMT);
                break;
            case 99:        //Si se recibe un "c" manda la informaci�n de las unidades presi�n:
                TXREG = (presion_uni);
                while(!TXSTAbits.TRMT);
                break;
            case 100:        //Si se recibe un "d" manda la informaci�n de la luminosidad milares:
                TXREG = (lux_mil);
                while(!TXSTAbits.TRMT);
                break;
            case 101:        //Si se recibe un "e" manda la informaci�n de la luminosidad centenas:
                TXREG = (lux_cen);
                while(!TXSTAbits.TRMT);
                break;
                
            case 102:        //Si se recibe un "f" manda la informaci�n de la luminosidad decenas:
                TXREG = (lux_dec);
                while(!TXSTAbits.TRMT);
                break;
                
            case 103:        //Si se recibe un "g" manda la informaci�n de la luminosidad unidades:
                TXREG = (lux_uni); 
                while(!TXSTAbits.TRMT);
                break;
            
            case 104:       // Si se recibe un "h" manda la informaci�n del �ngulo centenas:
                TXREG = (ang_cen);
                while(!TXSTAbits.TRMT);
                break;
             
            case 105:       // Si se recibe un "i" manda la informaci�n del �ngulo decenas:
                TXREG = (ang_dec);
                while(!TXSTAbits.TRMT);
                break;
                
            case 106:       // Si se recibe un "j" manda la informaci�n del �ngulo unidades:
                TXREG = (ang_uni);
                while(!TXSTAbits.TRMT);
                break;
            
            case 107:       // Si se recibe un "k" manda la informaci�n si est� I/O la puerta:
                TXREG = (door);
                while(!TXSTAbits.TRMT);
                break;
                
            default:        //Env�a un ! que no s� recibi� ningun dato de los anteriores.
                TXREG = (0x21);
                while(!TXSTAbits.TRMT);
                break;
        }
    }
}

/*------------------------- Menu Princioal -----------------------*/
void main(void) 
{
    setup();
    /*----------------------- LOOP PRINCIPAL -----------------------*/
    while(1)
    {
        /*----------- COMENZAR ADC -----------*/
        adc_start();
        
        /*----------- MOTOR STEPPER -----------*/
        if(!RB0 && (PORTBbits.RB4 =0) && (PORTBbits.RB5 =0))
        {
            PORTBbits.RB4 =1;
            PORTBbits.RB5 =1;
            door = 0x31;        // "1" en ascii
        }
        if(!RB0 && (PORTBbits.RB4 =1) && (PORTBbits.RB5 =1))
        {
            PORTBbits.RB4 =0;
            PORTBbits.RB5 =0;
            door = 0x30;        // "0" en ascii
        }
        
        /*----------- COMUNICACI�N I2C -----------*/
        //Leemos la presi�n en 8 bits.
        presion = BMP280_Read8(0xF9);
        //Traemos los 4bytes de info del luminosidad
        lux1 = Info1();
        lux2 = Info2();
        lux3 = Info3();
        lux4 = Info4();
        
        /*----------- MOTOR DC -----------*/
        if(lux1 < 1)        // Si el Lux est� menos de 5k
        {
            motor = 1;
            __delay_ms(1000);
            motor = 0;
            __delay_ms(1000);
        }
        
        /*----------- CONVERTIR EN ASCII -----------*/
        //Sacar centenas, decenas y unidades para conversi�n a ascii (+48)
        presion_cen = centenascentenas(presion);
        presion_dec = decenasdecenas(presion);
        presion_uni = uniunidades(presion);
        
        ang_cen = centenascentenas(ang);
        ang_dec = decenasdecenas(ang);
        ang_uni = uniunidades(ang);
        
        lux2_mil = milares(lux2);
        lux2_cen = centenas(lux2);
        lux2_dec = decenas(lux2);
        lux2_uni = unidades(lux2);
        
        lux3_cen = centenas(lux3);
        lux3_dec = decenas(lux3);
        lux3_uni = unidades(lux3);
        
        lux4_dec = decenas_decenas(lux4);
        lux4_uni = decenas_unidades(lux4);
        
        lux_mil = lux1+lux2_cen;
        lux_cen = lux2_cen+lux3_cen;
        lux_dec = lux2_dec+lux3_dec+lux4_dec;
        lux_uni = lux2_uni+lux3_uni+lux4_uni;
        
    }
    return;
}

void setup(void)
{
    ANSEL = 0x01;   //AN0
    ANSELH = 0;
    
    PORTA = 0;
    PORTB = 0;
    PORTC = 0;
    PORTD = 0;
    PORTE = 0;
    TRISA = 0;
    TRISB = 0;
    TRISC = 0;
    TRISD = 0;
    TRISBbits.TRISB0 = 1;
    PORTBbits.RB0 = 1;
    
    OSCCONbits.IRCF = 0b110;    // 4MHz
    SCS = 1;
    
    USART_Config(4,1,1);
    adc_init(2,0,0);
    PWM_CONFIG();
    BMP280_Configure(0x03, 0x01, 0x01, 0x00,0x05);
    BMP280_begin(0x03, 0x01, 0x01, 0x00,0x05);
    I2C_Master_Init(I2C_SPEED);
}

//Funci�n de mapeo:
unsigned short map(uint8_t x, uint8_t x0, uint8_t x1, 
            unsigned short y0, unsigned short y1){
    return (unsigned short)(y0+((float)(y1-y0)/(x1-x0))*(x-x0));
}

