#include "TSL2561.h"
#include "I2C.h"

#define XTAL_FREQ 4000000
//FUNCIONA PARA DESPERTAR EL MODULO DE LUMINOSIDAD
void WakeUp_TSL2561(void){
    I2C_Master_Start();
    I2C_Master_Write(ADDRESS_2);//Direcci�n del modulo
    I2C_Master_Write(0x00);     // Vamos a CONTROL Register
    I2C_Master_Write(0x03);     //0X03 ES NECESARIO PARA QUE DESPIERTE EL MODULO
    I2C_Master_Stop();
    __delay_ms(400);
    return;
}

void Sleep_TSL2561(void){
    I2C_Master_Start();
    I2C_Master_Write(ADDRESS_2);//Direcci�n del modulo
    I2C_Master_Write(0x00);     // Vamos a CONTROL Register
    I2C_Master_Write(0x00);     // Lo apagamos
    I2C_Master_Stop();
    return;
}

void Config_TSL2561(void)
{
    I2C_Master_Start();
    I2C_Master_Write(0x01);     // Vamos a TIMING Register
    I2C_Master_Write(0b00001010);     //Ganacia X1, Comienza el integration time cada 402ms
    I2C_Master_Stop();
}

unsigned int Read_DataLow_CH0_TSL2561(void)
{
    unsigned int DataLow_CH0;
    I2C_Master_Start();
    I2C_Master_Write(0x39);     // Direcci�n del modulo
    I2C_Master_Write(0xAC);     // Nos ubicamos a DataLow del CH0 del modulo
    I2C_Master_Write(0X0c);
    DataLow_CH0 = I2C_Master_Read(0);
    return DataLow_CH0;
}

unsigned int Read_DataHigh_CH0_TSL2561(void)
{
    unsigned int DataHigh_CH0;
    I2C_Master_Start();
    I2C_Master_Write(0x39);     // Direcci�n del modulo
    I2C_Master_Write(0xAC);     // Nos ubicamos a DataLow del CH0 del modulo
    I2C_Master_Write(0X0D);
    DataHigh_CH0 = I2C_Master_Read(0);
    return DataHigh_CH0;
}

unsigned int CH0_TSL2561(void)
{
    WakeUp_TSL2561();
    Config_TSL2561();
    unsigned int DataHigh_CH0;
    unsigned int DataLow_CH0;
    unsigned int CH0;
    DataLow_CH0  = Read_DataLow_CH0_TSL2561();
    DataHigh_CH0 = Read_DataHigh_CH0_TSL2561();
    CH0 = ((256 & DataHigh_CH0) | DataLow_CH0);
    return CH0;
}

unsigned int Read_DataLow_CH1_TSL2561(void)
{
    unsigned int DataLow_CH1;
    I2C_Master_Start();
    I2C_Master_Write(0x39);     // Direcci�n del modulo
    I2C_Master_Write(0xAE);     // Nos ubicamos a DataLow del CH0 del modulo
    I2C_Master_Write(0X0E);
    DataLow_CH1 = I2C_Master_Read(0);
    return DataLow_CH1;
}

unsigned int Read_DataHigh_CH1_TSL2561(void)
{
    unsigned int DataHigh_CH1;
    I2C_Master_Start();
    I2C_Master_Write(0x39);     // Direcci�n del modulo
    I2C_Master_Write(0xAE);     // Nos ubicamos a DataLow del CH0 del modulo
    I2C_Master_Write(0X0F);
    DataHigh_CH1 = I2C_Master_Read(0);
    return DataHigh_CH1;
}

unsigned int CH1_TSL2561(void)
{
    WakeUp_TSL2561();
    unsigned int DataHigh_CH1;
    unsigned int DataLow_CH1;
    unsigned int CH1;
    DataLow_CH1  = Read_DataLow_CH1_TSL2561();
    DataHigh_CH1 = Read_DataHigh_CH1_TSL2561();
    CH1 = (unsigned int)((256 & DataHigh_CH1) | DataLow_CH1);
    return CH1;
}

unsigned int light_intesity(uint8_t percent)
{
    unsigned int T_Lower;
    unsigned int CH0;
    CH0 = CH0_TSL2561();
    T_Lower =  CH0 - (CH0*percent/100);
    I2C_Master_Start();
    I2C_Master_Write(0x39);     // Direcci�n del modulo
    I2C_Master_Write(0xA2);     // Nos ubicamos en la direcci�n del lower threshold register
    I2C_Master_Write(T_Lower);  // Mandamos cuando es igual o menor inicie la interrupci�n
    I2C_Master_Stop();
    
    I2C_Master_Write(0x39);     // Direcci�n del modulo
    I2C_Master_Write(0x86);     // Nos ubicamos en la direcci�n de la INTERRUPT register
    I2C_Master_Write(0X23);     // Funci�n de alarma, PERSIST = 3
    I2C_Master_Stop();
}

unsigned int CalculateLux(unsigned int iGain, unsigned int tInt, int iType)
{
    unsigned int ch0, ch1;
    unsigned long chScale;
    unsigned long channel1;
    unsigned long channel0;
    ch0 = CH1_TSL2561();
    ch1 = CH0_TSL2561();
    
    switch (tInt){
        
        case 0:    // 13.7 msec
            chScale = CHSCALE_TINT0;
            break;
        case 1:    // 101 msec
            chScale = CHSCALE_TINT1;
            break;
        default:   // assume no scaling
            chScale = (1 << CH_SCALE);
            break;
    }
    // scale if gain is NOT 16X
    if (!iGain) chScale = chScale << 4;   // scale 1X to 16X
    // scale the channel values
    channel0 = (ch0 * chScale) >> CH_SCALE;
    channel1 = (ch1 * chScale) >> CH_SCALE;
    
    // find the ratio of the channel values (Channel1/Channel0)
    // protect against divide by zero
    unsigned long ratio1 = 0;
    if (channel0 != 0) ratio1 = (channel1 << (RATIO_SCALE+1)) / channel0;
    // round the ratio value
    unsigned long ratio = (ratio1 + 1) >> 1;
    // is ratio <= eachBreak ?
    unsigned int b, m;
    switch (iType){
        
        case 0: // T, FN and CL package
            if ((ratio >= 0) && (ratio <= K1T)){b=B1T; m=M1T;}
            else if (ratio <= K2T){b=B2T; m=M2T;}
            else if (ratio <= K3T){b=B3T; m=M3T;}
            else if (ratio <= K4T){b=B4T; m=M4T;}
            else if (ratio <= K5T){b=B5T; m=M5T;}
            else if (ratio <= K6T){b=B6T; m=M6T;}
            else if (ratio <= K7T){b=B7T; m=M7T;}
            else if (ratio > K8T){b=B8T; m=M8T;}
            break;
        case 1:// CS package
            if ((ratio >= 0) && (ratio <= K1C)){b=B1C; m=M1C;}
            else if (ratio <= K2C){b=B2C; m=M2C;}
            else if (ratio <= K3C){b=B3C; m=M3C;}
            else if (ratio <= K4C){b=B4C; m=M4C;}
            else if (ratio <= K5C){b=B5C; m=M5C;}
            else if (ratio <= K6C){b=B6C; m=M6C;}
            else if (ratio <= K7C){b=B7C; m=M7C;}
            else if (ratio > K8C) {b=B8C; m=M8C;}
            break;
    }
unsigned long temp;
temp = ((channel0 * b) - (channel1 * m));
// do not allow negative lux value
if (temp < 0) 
    temp = 0;
// round lsb (2^(LUX_SCALE?1))
temp += (1 << (LUX_SCALE - 1));
// strip off fractional portion
unsigned long lux = temp >> LUX_SCALE;  //32bits -> 4bytes
light_intesity(30);         //Si baja del 30% de luminosidad prende el motor.
// separaci�n de bytes:
return(lux);
}
// separaci�n de bytes:
//info1 -> lux1 es para el byte m�s significativo
//info2 -> lux2 es para el 2do byte mas significativo
//info3 -> lux3 es para el 2do byte menos significativo 
//info4 -> lux4 es para el byte menos significativo
uint8_t Info1(void)
{
    unsigned long lux;
    lux = CalculateLux(1,1,0);
    uint8_t lux1;
    lux1 = (uint8_t)(255 & (lux >> 24));
    return lux1;
}
uint8_t Info2(void)
{
    unsigned long lux;
    lux = CalculateLux(1,1,0);
    uint8_t lux2;
    lux2 = (uint8_t)(255 & (lux >> 16));
    return lux2;
}
uint8_t Info3(void)
{
    unsigned long lux;
    lux = CalculateLux(1,1,0);
    uint8_t lux3;
    lux3 = (uint8_t)(255 & (lux >> 8));
    return lux3;
}
uint8_t Info4(void)
{
    unsigned long lux;
    lux = CalculateLux(1,1,0);
    uint8_t lux4;
    lux4 = (uint8_t)(255 & (lux >> 0));
    return lux4;
}