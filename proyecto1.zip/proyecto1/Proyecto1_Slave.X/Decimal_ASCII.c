/* 
 * File:   Conversor_Decimal_ASCII.c
 * Author: 50247
 *
 * Created on 23 de septiembre de 2022, 09:11 AM
 */

#include "Decimal_ASCII.h"

uint8_t milares(uint8_t variable){        // Funci�n para obtener valor decimal
    uint8_t valor;
    uint8_t Primer_digito;
    
    valor = variable;                  
    Primer_digito = (valor/1000);               //Valor del cuarto digito
    Primer_digito = Primer_digito + 48;          //Conversi�n a ascii
    return Primer_digito;
}
uint8_t centenas(uint8_t variable){        // Funci�n para obtener valor decimal
    uint8_t valor;
    uint8_t Primer_digito;
    uint8_t Segundo_digito;
    
    valor = variable;                  
    Primer_digito = (valor/1000);               //Valor del cuarto digito
    valor = (valor - (Primer_digito*1000));
    Segundo_digito = (valor/100);               //Valor del tercero digito
    
    Primer_digito = Primer_digito + 48;          //Conversi�n a ascii
    Segundo_digito = Segundo_digito + 48;
    return Segundo_digito;
}

uint8_t decenas(uint8_t variable){        // Funci�n para obtener valor decimal
    uint8_t valor;
    uint8_t Primer_digito;
    uint8_t Segundo_digito;
    uint8_t Tercer_digito;
    
    valor = variable;                  
    Primer_digito = (valor/1000);               //Valor del cuarto digito
    valor = (valor - (Primer_digito*1000));
    Segundo_digito = (valor/100);               //Valor del tercero digito
    valor = (valor - (Segundo_digito*100));
    Tercer_digito = valor/10;                   //Valor del segundo digito
    
    Primer_digito  = Primer_digito  + 48;          //Conversi�n a ascii
    Segundo_digito = Segundo_digito + 48;
    Tercer_digito  = Tercer_digito  + 48;
    return Tercer_digito;
}

uint8_t unidades(uint8_t variable){        // Funci�n para obtener valor decimal
    uint8_t valor;
    uint8_t Primer_digito;
    uint8_t Segundo_digito;
    uint8_t Tercer_digito;
    uint8_t Cuarto_digito;
    
    valor = variable;                  
    Primer_digito = (valor/1000);               //Valor del cuarto digito
    
    valor = (uint8_t)(valor - (Primer_digito*1000));
    Segundo_digito = (valor/100);               //Valor del tercero digito
    
    valor = (uint8_t)(valor - (Segundo_digito*100));
    Tercer_digito = valor/10;                   //Valor del segundo digito
    
    valor = (uint8_t)(valor - (Tercer_digito*10));      
    Cuarto_digito = valor;                      //Valor del primer digito
    
    Primer_digito = Primer_digito + 48;          //Conversi�n a ascii
    Segundo_digito = Segundo_digito + 48;
    Tercer_digito = Tercer_digito + 48;
    Cuarto_digito = Cuarto_digito +48; 
    return Cuarto_digito;
}

uint8_t centenascentenas(uint8_t variable)
{
    uint8_t valor;
    uint8_t Primer_digito;
    
    valor = variable;                  
    Primer_digito = (valor/100) ;                //Valor del tercer digito
    Primer_digito = Primer_digito + 48;          //Conversion a ascii
    return Primer_digito;
}

uint8_t decenasdecenas(uint8_t variable)
{
    uint8_t valor;
    uint8_t Primer_digito;
    uint8_t Segundo_digito;
    
    valor = variable;                  
    Primer_digito = (valor/100) ;                //Valor del tercer digito
    valor = (valor - (Primer_digito*100));
    Segundo_digito = (valor/10);              //Valor del segundo digito
    Segundo_digito = Segundo_digito + 48;
    return Segundo_digito;
}

uint8_t uniunidades(uint8_t variable)
{
    uint8_t valor;
    uint8_t Primer_digito;
    uint8_t Segundo_digito;
    uint8_t Tercer_digito;
    
    valor = variable;                  
    Primer_digito = (valor/100) ;                //Valor del tercer digito
    valor = (valor - (Primer_digito*100));
    Segundo_digito = (valor/10);              //Valor del segundo digito
    valor = (valor - (Segundo_digito*10));
    Tercer_digito = valor;                //Valor del primer digito
    
    Primer_digito = Primer_digito + 48;          //Conversion a ascii
    Segundo_digito = Segundo_digito + 48;
    Tercer_digito = Tercer_digito + 48;
    return Segundo_digito;
}
uint8_t decenas_unidades(uint8_t variable)
{
    uint8_t valor;
    uint8_t Primer_digito;
    uint8_t Segundo_digito;
    
    valor = variable;                  
    Primer_digito = (valor/10) ;                //Valor del tercer digito
    valor = (valor - (Primer_digito*10));
    Segundo_digito = valor;              //Valor del segundo digito
    Segundo_digito = Segundo_digito + 48;
    return Segundo_digito;
}
uint8_t decenas_decenas(uint8_t variable)
{
    uint8_t valor;
    uint8_t Primer_digito;
    uint8_t Segundo_digito;
    
    valor = variable;                  
    Primer_digito = (valor/10) ;                //Valor del tercer digito
    valor = (valor - (Primer_digito*10));
    Segundo_digito = valor;              //Valor del segundo digito
    Segundo_digito = Segundo_digito + 48;
    return Primer_digito;
}

